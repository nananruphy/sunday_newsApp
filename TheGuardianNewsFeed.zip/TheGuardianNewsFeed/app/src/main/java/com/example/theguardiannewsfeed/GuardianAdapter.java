package com.example.theguardiannewsfeed;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;

public class GuardianAdapter extends ArrayAdapter<Feed_Item> {
    public GuardianAdapter(Context context, ArrayList<Feed_Item> newsItems) {
        super(context, 0, newsItems);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_items, parent, false);
        }

        final Feed_Item currentNewsItem = getItem(position);
        TextView titleTextView = (TextView) listItemView.findViewById(R.id.title_tv);
        titleTextView.setText(currentNewsItem.getWebTitle());

        ImageView thumbnailImageView = (ImageView) listItemView.findViewById(R.id.image);
        if (currentNewsItem.hasThumbnail()) {
            new DownloadImageTask(thumbnailImageView)
                    .execute(currentNewsItem.getThumbnailLink());
        } else {
            thumbnailImageView.setVisibility(View.GONE);
        }

        return listItemView;
    }


    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView myImage;

        public DownloadImageTask(ImageView bmImage) {
            this.myImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap icon = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                icon = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error-InBackground", e.getMessage());
                e.printStackTrace();
            }
            return icon;
        }

        protected void onPostExecute(Bitmap result) {
            myImage.setImageBitmap(result);
        }
    }
}
